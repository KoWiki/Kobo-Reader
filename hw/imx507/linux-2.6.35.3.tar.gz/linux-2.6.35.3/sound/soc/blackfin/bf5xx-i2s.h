/*
 * sound/soc/blackfin/bf5xx-i2s.h
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#ifndef _BF5XX_I2S_H
#define _BF5XX_I2S_H

extern struct snd_soc_dai bf5xx_i2s_dai;

#endif
