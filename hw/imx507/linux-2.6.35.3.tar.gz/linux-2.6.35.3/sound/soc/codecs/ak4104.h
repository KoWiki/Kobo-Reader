#ifndef _AK4104_H
#define _AK4104_H

extern struct snd_soc_dai ak4104_dai;
extern struct snd_soc_codec_device soc_codec_device_ak4104;

#endif
